import Tablesaw from '../../dist/tablesaw';

console.log( "this should be the tablesaw object: ", Tablesaw );

