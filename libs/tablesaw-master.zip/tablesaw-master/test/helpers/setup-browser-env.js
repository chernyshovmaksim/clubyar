var browserEnv = require("browser-env");

browserEnv(["window", "document", "navigator"]);
